<?php
$params = fox_post_group1_params();