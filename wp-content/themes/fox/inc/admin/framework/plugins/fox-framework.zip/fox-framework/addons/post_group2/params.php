<?php
$params = fox_post_group2_params();