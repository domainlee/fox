<?php
$params = fox_heading_params();