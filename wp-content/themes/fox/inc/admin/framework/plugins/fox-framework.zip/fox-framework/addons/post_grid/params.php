<?php
$params = fox_blog_params( 'grid' );