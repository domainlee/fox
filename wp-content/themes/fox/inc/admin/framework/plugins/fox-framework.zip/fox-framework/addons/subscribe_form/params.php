<?php
$params = fox_subscribe_form_params();